console.log("what is happening?");

let track = document.querySelector(".carousel_track");
let slides = Array.from(track.children);
let dotsNav = document.querySelector(".carousel_nav");
let dots = Array.from(dotsNav.children);

let slidesWidth = slides[0].getBoundingClientRect().width;
slides.forEach((slide, index) => {           
    slide.style.left = slidesWidth * index + "px";
});

function move_slide(track, current_slide, target_slide) {
    track.style.transform = 'translateX(-' +target_slide.style.left + ')';
    current_slide.classList.remove('carousel-current');
    target_slide.classList.add('carousel-current');
}

dotsNav.addEventListener('click', e => {         
    let targetDot = e.target.closest('button');
    if (!targetDot) return;
    let current_slide = track.querySelector(".carousel-current");
    let current_dot = dotsNav.querySelector(".current-indicator");
    let target_index = dots.findIndex(dot => dot === targetDot);
    let target_slide = slides[target_index];
    
    move_slide(track, current_slide, target_slide);

    current_dot.classList.remove('current-indicator');
    targetDot.classList.add('current-indicator');
});

setInterval(function(){
    let current_slide = track.querySelector(".carousel-current");
    let current_dot = dotsNav.querySelector(".current-indicator");
    let target_dot = current_dot.nextElementSibling;
    if(!target_dot){
        target_dot = dots[0];
    }
    let target_index = dots.findIndex(dot => dot === target_dot);
    let target_slide = slides[target_index];

    move_slide(track, current_slide, target_slide);

    current_dot.classList.remove('current-indicator');
    target_dot.classList.add('current-indicator');
},5000);
