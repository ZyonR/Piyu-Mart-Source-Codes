<?php
    $folderPath = "../images/*";
    $all_raw_images = glob($folderPath);
    foreach($all_raw_images as $ind=>$file){
        if($file and $ind < 5){
            if($ind == 0){
                echo"
                <li class='carousel_slide carousel-current'>
                    <div class='imagewithtitlecarousel_slide'>
                        <img src=".$file." alt='' class='carousel_image'>
                    </div>
                </li>
                ";
            }else{
                echo"
                <li class='carousel_slide'>
                    <div class='imagewithtitlecarousel_slide'>
                        <img src=".$file." alt='' class='carousel_image'>
                    </div>
                </li>
                ";
            }
        }
    }
?>
