<body>
    <div class="cartTab">
        <h1>Shopping Cart</h1>
        <div class="listCart">
            Show items here
            <!-- Check cart.js -->
        </div>
        <div class="btn">
            <button class="close">Close</button>
            <button class="checkout">Checkout</button>
        </div>
    </div>

    <div class="paymentTab">
        <h1>Payment Options</h1>
        <div class="listPayments">
            To be announce on the show options here!
        </div>
        <div class="btn">
            <button class="cancel">Cancel</button>
            <button class="proceed">Proceed</button>
        </div>
    </div>
    <script src="../cart-payment/cart.js" type="module" async defer></script>
</body>