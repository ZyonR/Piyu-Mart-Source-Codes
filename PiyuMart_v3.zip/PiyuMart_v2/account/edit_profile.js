const editProfileBtn = document.querySelector('.edit-btn');
const labelEditProfileImg = document.querySelector('.profile-img');
const indicateEditProfileImg = document.querySelector('.indicate_edit_profile_img');

editProfileBtn.addEventListener("click",e =>{
    const profileInformation = (Array.from(document.querySelectorAll(".profile-title-aspects-value"))).slice(0,3);
    console.log(profileInformation);

    if(profileInformation[0].contentEditable==='false'){

        indicateEditProfileImg.style.display = 'block';
        labelEditProfileImg.style.border='0.1em solid white';
        labelEditProfileImg.setAttribute('for', 'shop_img_inputer');
        e.target.innerHTML = "Save Profile";

        profileInformation.forEach(element => {
            element.contentEditable = true;
            element.focus();
            element.classList.add('contentIsEditable');
        });

    }else{
        indicateEditProfileImg.style.display = 'none';
        labelEditProfileImg.style.border='none';
        labelEditProfileImg.removeAttribute('for');
        e.target.innerHTML = "Edit Profile";

        profileInformation.forEach(element => {
            element.contentEditable = false;
            element.blur();
            element.classList.remove('contentIsEditable');
        });
    }
});


