const editShopBtn = document.querySelector('.shop-edit-btn');
const labelEditProfileImg = document.querySelector('.shop-img');
const indicateEditProfileImg = document.querySelector('.indicate_edit_profile_img');

function saveEditedShopProfile(shopName){
    console.log("saved");
}
editShopBtn.addEventListener("click",e =>{
    const shopName = document.querySelector(".shop-name-title");
    if(shopName.contentEditable==='false'){
        shopName.contentEditable = true;
        shopName.focus();
        e.target.innerHTML = "Save Shop Profile";
        indicateEditProfileImg.style.display = 'block';
        labelEditProfileImg.style.border='0.1em solid white';
        labelEditProfileImg.setAttribute('for', 'shop_img_inputer');
    }else{
        shopName.contentEditable = false;
        shopName.blur();
        e.target.innerHTML = "Edit Shop Profile";
        saveEditedShopProfile(shopName);
        indicateEditProfileImg.style.display = 'none';
        labelEditProfileImg.style.border='0.1em solid white';
        labelEditProfileImg.style.border='none';
        labelEditProfileImg.removeAttribute('for');
    }
});
labelEditProfileImg.addEventListener('click', clickEvent => {
    const inputProfileImg = document.querySelector('.shop_img_inputer');

    inputProfileImg.addEventListener('change', changeEvent => {
        const newProfileImg = inputProfileImg.files[0];
        const reader = new FileReader();

        reader.onload = function(loadEvent) {
            clickEvent.target.src = loadEvent.target.result;
        };
        reader.readAsDataURL(newProfileImg);
    });
});
