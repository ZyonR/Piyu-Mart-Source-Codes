<?php
function review_replies($arr)
{
    foreach ($arr as $value) {
        echo "
            <div class='review'>
                <div class='review-top-section'>
                    <div class='review-account-img-2'>" . $value['img'] . "</div>
                    <div class='review-account-info'>
                        <p class='review-account-info-name-2'>" . $value['name'] . "</p>
                        <p class='review-account-info-date-2'>" . $value['review-posted'] . "</p>
                    </div>
                </div>
                <p class='review-paragraph-2'>" . $value['review'] . "</p>
                <div class='like-share-section'>
                    <button class='like-share-reply-btn-2'>Reply</button>
                    <button class='like-share-reply-btn-2'>Like</button>
                    <button class='like-share-reply-btn-2'>Delete</button>
                </div>
            </div>
            ";
    }
}
$arr = array(
    [
        "name" => "Regis Luctano",
        "img" => "",
        "review-posted" => "2024-01-01",
        "review" => "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."
    ], [
        "name" => "Regis Luctano",
        "img" => "",
        "review-posted" => "2024-01-01",
        "review" => "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."
    ], [
        "name" => "Regis Luctano",
        "img" => "",
        "review-posted" => "2024-01-01",
        "review" => "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."
    ], [
        "name" => "Regis Luctano",
        "img" => "",
        "review-posted" => "2024-01-01",
        "review" => "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."
    ]
);
review_replies($arr);
