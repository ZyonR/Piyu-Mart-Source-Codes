<?php
$products = [
    [
        "id" => 1,
        "name" => "Bottomless Shirt",
        "price" => 200,
        "description" => "May your serviced be found better.",
        "image" => "../images/1.png"
    ],
    [
        "id" => 2,
        "name" => "Mystic T-Shirt",
        "price" => 150,
        "description" => "Unlock the mysteries of comfort and style.",
        "image" => "../images/2.png"
    ],
    [
        "id" => 3,
        "name" => "Cosmic Tee",
        "price" => 180,
        "description" => "Travel the universe in ultimate comfort.",
        "image" => "../images/3.png"
    ],
    [
        "id" => 4,
        "name" => "Vortex V-Neck",
        "price" => 220,
        "description" => "Swirl into fashion with the Vortex V-Neck.",
        "image" => "../images/4.png"
    ],
    [
        "id" => 5,
        "name" => "Galaxy Garb",
        "price" => 170,
        "description" => "Wear the galaxy on your sleeve.",
        "image" => "../images/5.png"
    ],
    [
        "id" => 6,
        "name" => "Stellar Shirt",
        "price" => 190,
        "description" => "Shine bright with the Stellar Shirt.",
        "image" => "../images/6.png"
    ],
    [
        "id" => 7,
        "name" => "Nebula Top",
        "price" => 210,
        "description" => "Embrace the nebula of comfort and style.",
        "image" => "../images/7.png"
    ],
    [
        "id" => 8,
        "name" => "Galactic Hoodie",
        "price" => 240,
        "description" => "Wrap yourself in the cosmic embrace of this luxurious hoodie.",
        "image" => "../images/8.png"
    ]
];
?>

<?php
foreach ($products as $product) {
    echo '
        <section class="card">
            <div class="product">
                <img src="' . $product["image"] . '">
                <h3>' . $product["name"] . '</h3>
                <p>Lorem ipsum is a type of placeholder</p>
                <h6>₱ ' . $product["price"] . '</h6>
                
                <ul>
                    <li><i class="bx bxs-star"></i></li>
                    <li><i class="bx bxs-star"></i></li>
                    <li><i class="bx bxs-star-half"></i></li>
                    <li><i class="bx bx-star"></i></li>
                    <li><i class="bx bx-star"></i></li>
                </ul>
                <button class="addCart" data-id="' . $product["id"] . '">Add to Cart</button>
            </div>
        </section>
    ';
}
?>