<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../base.css">
    <link rel="stylesheet" href="../base2.css">
    <link rel="stylesheet" href="home-styles.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <title>Document</title>
</head>

<body>
    <?php include "../header.php" ?>
    <section class="container">
        <div class="ads-space"></div>
        <br>
        <section class="content">
            <div class="hero-section">
                <!-- Hero must have a logic based here for dynamically changing -->
                <div class="hero">
                    <!-- For mobile screen sizes use object-fit and image manipulation to direct position of image -->
                    <div class="shop-featured-product">
                        <h1 class="hero-product-name">WOHOO Candy Streaks</h1>
                        <p class="hero-product-price">Php 59.99</p>
                        <button class="add-to-cart-btn">Add to Cart</button>
                    </div>
                </div>
            </div>
            <br><br>
            <section class="all-sectioned-items">
                <div class="featured-products-container">
                    <h2 class="product-section-title">Featured</h2>
                    <div class="Featured">
                        <div id="temporaryContent">
                            <div class="gallery">
                                <?php include "featured.php"; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="new-products-container">
                    <h2 class="product-section-title">New Arraivals</h2>
                    <!-- Input products here (turn into a function) -->
                    <div class="New">
                        <div id="temporaryContent">
                            <div class="gallery">
                                <?php include "new.php"; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="sale-products-container">
                    <h2 class="product-section-title">Products on Sale</h2>
                    <!-- Input products here (turn into a function) -->
                    <div class="Sale">
                        <div id="temporaryContent">
                            <div class="gallery">
                                <?php include "sale.php"; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </section>
        <br>
        <div class="ads-space"></div>
    </section>
    <br>
    <?php include "../footer.php" ?>
</body>

</html>