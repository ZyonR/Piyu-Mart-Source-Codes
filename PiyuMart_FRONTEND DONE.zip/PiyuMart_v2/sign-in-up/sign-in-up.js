const login_register_box = document.querySelector('.login-register-box');
const login_link = document.querySelector('.login-link');
const register_link = document.querySelector('.register-link');

register_link.addEventListener('click', () => {
    login_register_box.classList.add('active');
});
login_link.addEventListener('click', () => {
    login_register_box.classList.remove('active');
});


const socialIconsDiv = document.querySelector('.social-icons');
const iconElements = socialIconsDiv.querySelectorAll('i');

// Add 'bx-burst' class to all 'i' elements on page load
iconElements.forEach(icon => icon.classList.add('bx-tada'));

// Remove 'bx-burst' class when hovering over the 'social-icons' div
socialIconsDiv.addEventListener('mouseover', () => {
    iconElements.forEach(icon => icon.classList.remove('bx-tada'));
});

// Add 'bx-burst' class when no longer hovering over the 'social-icons' div
 socialIconsDiv.addEventListener('mouseout', () => {
    iconElements.forEach(icon => icon.classList.add('bx-tada'));
});