import Products from "./products15.js"; // Ensure the correct module is imported

const initializedGrid = () => {
    console.log(Products); // Determine whether the data delivered properly to the console
    let listProduct = document.querySelector('.gallery');
    listProduct.innerHTML = null;
    
    Products.forEach(product => {
        let newProduct = document.createElement('section');
        newProduct.classList.add('card');
        newProduct.innerHTML =
            `
                <img src="${product.image}">
                <h3> ${product.name} </h3>
                <p> Lorem ipsum is a type of placeholder </p>
                <h6>₱ ${product.price} </h6>

                <ul>
                    <li><i class='bx bxs-star' ></i></li>
                    <li><i class='bx bxs-star' ></i></li>
                    <li><i class='bx bxs-star-half' ></i></li>
                    <li><i class='bx bx-star' ></i></li>
                    <li><i class='bx bx-star' ></i></li>
                </ul>
                <button class="addCart" data-id = "${product.id}">Add to Card</button>
            `;
        listProduct.appendChild(newProduct);
    })
};

initializedGrid();