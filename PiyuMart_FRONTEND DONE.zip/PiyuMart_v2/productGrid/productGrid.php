<body>
    <div id="app"></div>
    <div id="temporaryContent">
        <div class="gallery">
            <!-- CHECK productGrid.js -->
        </div>
    </div>

    <script src="../productGrid/productGrid.js" type="module"></script>
</body>