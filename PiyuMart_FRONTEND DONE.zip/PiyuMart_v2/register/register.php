<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../base.css">
    <link rel="stylesheet" href="registration-styles.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="../base2.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <title>Document</title>
</head>

<body>
    <?php include "../header.php" ?>
    <section class="container">
        <div class="ads-space"></div>
        <br>
        <section class="content">
            <div class="terms-and-conditions-container">
                <h1 class="title-paragraph">Mechanics</h1>
                <p class="mechanics-paragraph">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Eget nullam non nisi est. Nibh mauris cursus mattis molestie a iaculis. Urna et pharetra pharetra massa massa ultricies. Fermentum posuere urna nec tincidunt. Tempor orci eu lobortis elementum nibh tellus. Sed enim ut sem viverra aliquet eget sit amet. Nunc consequat interdum varius sit amet mattis vulputate. At ultrices mi tempus imperdiet nulla malesuada pellentesque elit. Eleifend donec pretium vulputate sapien nec sagittis aliquam malesuada bibendum.</p>
                <h1 class="title-paragraph">Terms and Conditions</h1>
                <p class="terms-and-conditions-paragraph">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Eget nullam non nisi est. Nibh mauris cursus mattis molestie a iaculis. Urna et pharetra pharetra massa massa ultricies. Fermentum posuere urna nec tincidunt. Tempor orci eu lobortis elementum nibh tellus. Sed enim ut sem viverra aliquet eget sit amet. Nunc consequat interdum varius sit amet mattis vulputate. At ultrices mi tempus imperdiet nulla malesuada pellentesque elit. Eleifend donec pretium vulputate sapien nec sagittis aliquam malesuada bibendum. Lacus laoreet non curabitur gravida arcu. Pulvinar pellentesque habitant morbi tristique senectus et netus et. Porta nibh venenatis cras sed felis eget velit aliquet sagittis. Pretium fusce id velit ut tortor. Massa sed elementum tempus egestas sed sed risus. Lobortis scelerisque fermentum dui faucibus in ornare quam viverra. Fermentum iaculis eu non diam phasellus vestibulum. Mauris nunc congue nisi vitae suscipit tellus mauris. Bibendum arcu vitae elementum curabitur vitae. Non curabitur gravida arcu ac tortor. Ridiculus mus mauris vitae ultricies leo integer malesuada nunc. Aenean sed adipiscing diam donec adipiscing tristique. Duis tristique sollicitudin nibh sit amet commodo nulla facilisi nullam. Sed ullamcorper morbi tincidunt ornare massa eget. Ultrices mi tempus imperdiet nulla. Mattis enim ut tellus elementum sagittis vitae et leo. Diam volutpat commodo sed egestas egestas. Pretium vulputate sapien nec sagittis aliquam malesuada bibendum arcu vitae. At elementum eu facilisis sed odio morbi. Sapien pellentesque habitant morbi tristique senectus. Sapien et ligula ullamcorper malesuada proin libero nunc consequat. Sociis natoque penatibus et magnis dis parturient montes nascetur. Pellentesque adipiscing commodo elit at imperdiet. Aliquam etiam erat velit scelerisque in. Amet commodo nulla facilisi nullam. Amet mauris commodo quis imperdiet. Turpis egestas maecenas pharetra convallis. Quis varius quam quisque id diam vel quam. Fusce ut placerat orci nulla pellentesque dignissim enim sit amet. Ante in nibh mauris cursus mattis molestie a iaculis at. Habitasse platea dictumst quisque sagittis purus. Tristique et egestas quis ipsum suspendisse ultrices. Ut ornare lectus sit amet est placerat. Aenean et tortor at risus viverra adipiscing at. In ornare quam viverra orci. Porttitor lacus luctus accumsan tortor posuere ac. Est placerat in egestas erat imperdiet. At risus viverra adipiscing at. Egestas congue quisque egestas diam. Tortor id aliquet lectus proin nibh. Tellus orci ac auctor augue mauris augue. Amet facilisis magna etiam tempor orci. Nulla aliquet porttitor lacus luctus accumsan tortor posuere ac ut. Eu facilisis sed odio morbi. Mauris in aliquam sem fringilla ut. Scelerisque in dictum non consectetur a erat nam at lectus. Bibendum enim facilisis gravida neque convallis a cras semper. Scelerisque mauris pellentesque pulvinar pellentesque habitant morbi tristique senectus et. Aliquam vestibulum morbi blandit cursus risus at ultrices. Nisl tincidunt eget nullam non nisi est sit. Fermentum posuere urna nec tincidunt praesent semper feugiat nibh sed. Pharetra diam sit amet nisl suscipit adipiscing. Commodo quis imperdiet massa tincidunt nunc pulvinar sapien. Egestas tellus rutrum tellus pellentesque eu tincidunt tortor aliquam. Ipsum dolor sit amet consectetur adipiscing elit pellentesque habitant morbi. Et netus et malesuada fames ac. Ipsum dolor sit amet consectetur. Sed turpis tincidunt id aliquet risus feugiat in ante metus. Consectetur adipiscing elit ut aliquam purus sit amet luctus venenatis. Non blandit massa enim nec dui nunc mattis enim. Tellus orci ac auctor augue mauris augue neque gravida. Eleifend quam adipiscing vitae proin sagittis. Vitae turpis massa sed elementum tempus egestas sed.</p>
                <form class='forms-terms-and-conditions' action='../individual-shop/indiv-shop.php'>
                    <fieldset>
                        <input type="checkbox" value="Yes" />
                        <label class="terms-and-conditions-title">I Agree with the Terms and Conditions</label>
                    </fieldset>
                    <fieldset class="insert-store-img-container">
                        <label class="store-image-title">Insert Store Image</label>
                        <input class="input-img-here" type="file">
                    </fieldset>
                    <fieldset class="store-submit-container">
                        <input class="store-name" type="text" placeholder="Input Store Name" />
                        <input class="terms-and-conditions-submit-btn" type="submit" value="Submit">
                    </fieldset>

                </form>
            </div>
        </section>
        <br>
        <div class="ads-space"></div>
    </section>
    <br>
    <br>
    <?php include "../footer.php" ?>
</body>

</html>