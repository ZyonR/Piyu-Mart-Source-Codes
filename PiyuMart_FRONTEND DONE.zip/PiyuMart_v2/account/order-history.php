<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title></title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        div.order-display {
            margin: 5rem 0;
            background: var(--dummybackground);

            border-radius: 0.5rem;
            overflow-y: scroll;

            table.order-display-table {
                backdrop-filter: blur(5px);

                @media (min-width: 768px) {
                    width: 100%;
                }

                @media (min-width: 620px) and (max-width: 767px) {
                    width: 45rem;
                }

                @media (min-width: 425px) and (max-width: 619px) {
                    width: 35rem;
                }

                @media (min-width: 320px) and (max-width: 424px) {
                    width: 30rem;
                }

                text-align: center;

                thead {
                    padding: 2rem;
                    font-size: 1.0rem;
                    background: var(--feu-white);

                    td {
                        padding: 1.5rem;
                        border-bottom: var(--background-color);
                    }
                }

                tr td a.btn {
                    display: block;
                    cursor: pointer;
                    border-radius: 20em;
                    border: 0.2rem solid var(--background-color);
                    margin: 0.5rem;
                    font-size: 0.75rem;
                    padding: 0.50rem 3.0rem;
                    color: var(--feu-white);
                    transition: 0.2s ease-out;

                    &:nth-child(1) {
                        background: var(--feu-green);

                        &:hover {
                            background: var(--alt-color-3);
                            transition: 0.2s ease-in;
                        }
                    }

                    &:nth-child(2) {
                        background: var(--background-color);

                        &:hover {
                            background: var(--alt-color-2);
                            transition: 0.2s ease-in;
                        }
                    }
                }
            }
        }
    </style>
</head>

<body>
    <div class="order-display">
        <table class="order-display-table">
            <thead>
                <td>Order Image</td>
                <td>Product Details</td>
                <td>Product ID</td>
                <td colspan="2">Other Actions</td>
            </thead>
            <tr>
                <td><img src="../images/1.png" height="100"></td>
                <td>
                    <span>Dummy Product Title</span>
                    <br><span>Dummy Product Rider</span>
                </td>
                <td>
                    <span>Dummy Current Status</span>
                    <br><span>Dummy Price</span>
                </td>
                <td>
                    <a href="../product/product.php" class="btn">Report Order</a>
                    <a href="../product/product.php" class="btn">Make a Review</a>
                </td>
            </tr>
            <tr>
                <td><img src="../images/2.png" height="100"></td>
                <td>
                    <span>Dummy Product Title</span>
                    <br><span>Dummy Product Rider</span>
                </td>
                <td>
                    <span>Dummy Current Status</span>
                    <br><span>Dummy Price</span>
                </td>
                <td>
                    <a href="../product/product.php" class="btn">Report Order</a>
                    <a href="../product/product.php" class="btn">Make a Review</a>
                </td>
            </tr>
            <tr>
                <td><img src="../images/3.png" height="100"></td>
                <td>
                    <span>Dummy Product Title</span>
                    <br><span>Dummy Product Rider</span>
                </td>
                <td>
                    <span>Dummy Current Status</span>
                    <br><span>Dummy Price</span>
                </td>
                <td>
                    <a href="../product/product.php" class="btn">Report Order</a>
                    <a href="../product/product.php" class="btn">Make a Review</a>
                </td>
            </tr>
        </table>
    </div>
    <script src="" async defer></script>
</body>

</html>