let container_tabs = document.getElementById("socials-information-container");

function reviews(){
    container_tabs.innerHTML="";
    let review = "";
    let reviews_arr = 
        [{
            "name": "Regis Luctano",
            "prod_id":121334,
            "img":"",
            "review_posted":"2024-01-01",
            "review":"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
            "parameters" : {"Product Quality":4.5,"Price":5,"Customer Service":4.7,"Packaging":3.5}
        },
        {
            "name": "Regis Luctano",
            "prod_id":121334,
            "img":"",
            "review_posted":"2024-01-01",
            "review":"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
            "parameters" : {"Product Quality":4.5,"Price":5,"Customer Service":4.7,"Packaging":3.5}
        },
        {
            "name": "Regis Luctano",
            "prod_id":121334,
            "img":"",
            "review_posted":"2024-01-01",
            "review":"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
            "parameters" : {"Product Quality":4.5,"Price":5,"Customer Service":4.7,"Packaging":3.5}
        }];
    reviews_arr.forEach(value=>{
        let params = "";
        for(const [key,val] of Object.entries(value.parameters)){
            params+=`<p class='review-parameters-text'>${key}: ${val}</p>`;
        }
        review += `
            <div class='review'>
                <div class='review-top-section'>
                    <div class='review-account-img'>${value.img}</div>
                    <div class='review-account-info'>
                        <p class='review-account-info-name'>${value.name}</p>
                        <p class='review-account-info-date'>${value.review_posted}</p>
                        <p class='review-account-info-product-id'>Product ID: ${value.prod_id}</p>
                    </div>
                </div>
                <div class='review-parameters-and-paragraph'>
                    <div class='review-parameters'>
                        ${params}
                    </div>
                    <p class='review-paragraph'>${value.review}</p>
                </div>
                <button class='delete-review-btn'>Delete Review</button>
            </div>
        `;
    });
    container_tabs.innerHTML = review;
}

function generator_accounts(){
    container_tabs.innerHTML="";
    let accounts = "";
    let accounts_arr = 
        [{
            "shop_name":"Dippy Dy Co. number 1 giddy",
            "shop_n_followers":12,
            "shop_img":"",
            "following":false
        },
        {
            "shop_name":"Dippy Dy Co. number 1 giddy",
            "shop_n_followers":12,
            "shop_img":"",
            "following":true
        },
        {
            "shop_name":"Dippy Dy Co. number 1 giddy",
            "shop_n_followers":12,
            "shop_img":"",
            "following":false
        }];
    accounts_arr.forEach(value=>{
        let status = "Follow";
        if(value.following){
            status = "Unfollow";
        }
        accounts += `
            <div class='shop-container'>
                <div class="shop-img-followers-name-container">
                    <div class='shop-img'>${value.shop_img}</div>
                    <div class='shop-base-info'>
                        <h2 class='shop-name'>${value.shop_name}</h2>
                        <p class='shop-n-followers'>${value.shop_n_followers} followers</p>
                    </div>
                </div>
                <button class='shop-follow-btn'>${status}</button>
            </div>
        `;
    });
    container_tabs.innerHTML = accounts;
}