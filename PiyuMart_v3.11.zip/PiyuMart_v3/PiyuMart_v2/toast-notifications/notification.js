let toastbox = document.getElementById('notification-panel');

let success_icon = '<i class="bx bxs-check-circle"></i>';
let error_icon = '<i class="bx bxs-x-circle" ></i>';
let warning_icon = '<i class="bx bxs-error"></i>';
let info_icon = '<i class="bx bxs-info-circle" ></i>';
let message1_success = success_icon + 'Successfully submitted!';
let message1_error = error_icon + 'Fix the error!';
let message1_invalid = warning_icon + 'Invalid input, check again!';
let message1_info = info_icon + 'Yada, yada!';

const notificationToast = (message)=> {
    let toast = document.createElement('section');
    toast.classList.add('toast');
    toast.innerHTML = message;
    toastbox.appendChild(toast);

    if (message.includes(error_icon)) {
        toast.classList.add('error');
    }

    if (message.includes(warning_icon)) {
        toast.classList.add('invalid');
    }

    if (message.includes(info_icon)) {
        toast.classList.add('info');
    }

    setTimeout(() => {
        toast.remove();
    }, 6000)
}
