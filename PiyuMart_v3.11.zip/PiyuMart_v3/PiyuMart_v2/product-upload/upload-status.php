<head>
    <style>
        body div.add-product-status {
            display: block;
            z-index: 10;
            left: 0;
            right: 0;
            background: var(--feu-green-dried);
            color: var(--feu-white);
            padding: 0.50rem 0.50rem;
            font-weight: bold;
            display: flex;
            flex-wrap: wrap;
            justify-content: center;

            @media (min-width: 769px) {
                position: relative;
                font-size: 0.80rem;
            }

            @media (max-width: 768px) {
                position: fixed;
                font-size: 0.50rem;
                bottom: 0;
            }

            span.message {
                margin: 0.50rem 0.50rem;
                padding: 0.5em 1.5em;
                border-radius: 20em;
                border: none;
                color: var(--background-color);

                &[data-id="bad"] {
                    background-color: var(--alt-color-2);
                }

                &[data-id="warning"] {
                    background-color: var(--alt-color-3);
                }

                &[data-id="good"] {
                    background-color: var(--alt-color-1);
                }
            }
        }
    </style>
</head>
<div class="add-product-status">
    <?php
    // if(isset($message)){
    //     foreach($message as $message){
    //         echo '<span class="message" data-id="type">'.$message.'</span>';
    //     }
    // }
    ?>


    <!-- NOTICE HOW data-id attributes makes CSS easier -->
    <span class="message" data-id="bad">
        <!--OTHER ERROR MESSAGES HERE-->
        <!--PLEASE COMPLETE ALL FEILDS-->
        <!--WE RECOMMEND TO HAVE AT LEAST 3 PRODUCT TAGS-->
        <!--ADD PRODUCT SUCCESSFUL-->
        <!-- PRODUCT STATUS CHECK! -->
        CODE RED: REALLY CONCERNING ERRORS
    </span>

    <span class="message" data-id="warning">
        <!--OTHER ERROR MESSAGES HERE-->
        <!--PLEASE COMPLETE ALL FEILDS-->
        <!-- WE RECOMMEND TO HAVE AT LEAST 3 PRODUCT TAGS -->
        <!--ADD PRODUCT SUCCESSFUL-->
        <!-- PRODUCT STATUS CHECK! -->
        CODE YELLOW: MISSING ENTRIES DECTECTED
    </span>

    <span class="message" data-id="good">
        <!--OTHER ERROR MESSAGES HERE-->
        <!--PLEASE COMPLETE ALL FEILDS-->
        <!--WE RECOMMEND TO HAVE AT LEAST 3 PRODUCT TAGS-->
        <!-- ADD PRODUCT SUCCESSFUL -->
        <!-- PRODUCT STATUS CHECK! -->
        CODE GREEN: SUCCESSFUL REQUEST
    </span>
</div>