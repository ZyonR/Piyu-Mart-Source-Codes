<header class="header">
    <a p class="piyumart-logo" href="../home/home.php">
        <p class="piyumart-logo">Piyu<span>MART</span></p>
    </a>
    <div class="search-bar-container">
        <input type="text" class="search-bar" />
        <button class="search-btn">Search</button>
    </div>
    <section class="my-account-cart-container">
        <a href="../account/account.php">Account</a>
        <div class="shop-cart">
            <i class='bx bx-cart'></i><span>0</span>
        </div>
    </section>
</header>
<header class="header-2">
    <nav class="navigation-bar-2">
        <a href="../home/home.php">Home</a>
        <a href="../about/about.php">About</a>
        <a href="../catalogue/catalogue.php">Catalogue</a>
        <a href="../shop/shop.php">Shops</a>
        <a class="search-link" href="../search/search.php">Search</a>
    </nav>
</header>
<?php include "../cart-payment/cart-cards.php" ?>
<div class="stretched-section">
</div>