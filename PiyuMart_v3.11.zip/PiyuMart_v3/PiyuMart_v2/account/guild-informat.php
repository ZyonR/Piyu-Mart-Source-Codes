
<?php
    if (!function_exists('information')) {
        function information($key, $val) {
            return (
                "<div class='basic-info-container'>
                    <p class='profile-title-aspects'>" . ucwords($key) . "</p>
                    <p class='profile-title-aspects-value'>" . $val . "</p>
                </div>"
            );
        }
    }
    if (!function_exists('privacy_information')) {
        function privacy_information($key, $val) {
            return (
                "
                <div class='basic-info-change-btn-container'>
                    <div class='basic-info-container'>
                        <p class='profile-title-aspects'>" . ucwords($key) . "</p>
                        <p class='profile-title-aspects-value'>" . $val . "</p>
                    </div>
                    <button class='change-privacy-info'>Change " . ucwords($key) . "</button>
                </div>
                "
            );
        }
    }
    if (!function_exists('shop_information')) {
        function shop_information($key, $val) {
            return (
                "
                <div class='basic-info-container'>
                    <p class='profile-title-aspects'>" . ucwords($key) . "</p>
                    <p class='profile-title-aspects-value'>" . $val . "</p>
                </div>
                "
            );
        }
    }
    
    if(isset($information_degree)){
        $arr = array();
        if($information_degree=="base"){
            $arr = array("username"=>"Wobbiligobbly","address"=> "1234 Elm Street Apt 5B Springfield, IL 62704 USA","contact number"=>"+63 9396113263");
            $arr = array_map(function($key,$val){
                return information($key,$val);
            },array_keys($arr),array_values($arr));
        }
        elseif($information_degree=="privacy"){
            $arr = array("password"=>"wobbiligobbly991!","email"=> "wobbiligobbly@gmail.com");
            $arr = array_map(function($key,$val){
                return privacy_information($key,$val);
            },array_keys($arr),array_values($arr));
        }elseif($information_degree=="shop"){
            $arr = array("Shop Name"=>"WOHOO","Store Id"=> "1002014351");
            $arr = array_map(function($key,$val){
                return shop_information($key,$val);
            },array_keys($arr),array_values($arr));
        }
        echo implode("",$arr);
    }
?>