import products from "../productGrid/products15.js";

const Cart = () => {
    // For the cart div
    let iconCart = document.querySelector('.shop-cart');
    let closeBtn = document.querySelector('.close');
    let cart = [];
    // For the payment div
    let checkout = document.querySelector('.checkout');
    let cancelBtn = document.querySelector('.cancel');
    // Both cart and payment influence the new classes' names for the <body> tag
    let body = document.body;

    // Import cart memory on initialization
    const importCartMemory = () => {
        if (localStorage.getItem('cart')) {
            cart = JSON.parse(localStorage.getItem('cart'));
        }
    };

    // Export cart memory to localStorage
    const exportCartMemory = () => {
        localStorage.setItem('cart', JSON.stringify(cart));
    };

    const setProductInCart = (idProduct, quantity, position) => {
        if (quantity > 0) { //The CART detected that there are any items that have been 'added to cart'
            if (position < 0) { // If that product does not exist yet in the CART
                cart.push({
                    product_id: idProduct,
                    quantity: quantity
                });
            } else { // If that product is already in the CART
                cart[position].quantity = quantity;
            }
        } else { //If that product is being removed
            cart.splice(position, 1);
        }
        refreshCartHTML();
        exportCartMemory();
    };

    const refreshCartHTML = () => {
        let listHTML = document.querySelector('.listCart');
        listHTML.innerHTML = '';
        let totalHTML = document.querySelector('.shop-cart span');
        let totalQuantity = 0;
        cart.forEach(item => {
            totalQuantity += item.quantity;
            let position = products.findIndex((value) => value.id == item.product_id);
            let info = products[position];
            let newItem = document.createElement('div');
            newItem.classList.add('item');
            newItem.innerHTML =
                `
                    <div class="image">
                        <img src="${info.image}"/>
                    </div>
                    <div class="name">
                        ${info.name}
                    </div>
                    <div class="totalPrice">
                        ₱ ${info.price * item.quantity}
                    </div>
                    <div class="quantity">
                        <span class="minus" data-id="${info.id}">-</span>
                        <span>${item.quantity}</span>
                        <span class="plus" data-id="${info.id}">+</span>
                    </div>
                `;
            listHTML.appendChild(newItem);
        });
        totalHTML.innerText = totalQuantity;
    };

    if (iconCart) {
        iconCart.addEventListener('click', () => {
            body.classList.toggle('activeTabCart');
            // The cart-icon can OPEN AND CLOSE the activeTabCart div
        });
    }

    if (closeBtn) {
        closeBtn.addEventListener('click', () => {
            body.classList.remove('activeTabCart');
        });
    }

    if (checkout) {
        checkout.addEventListener('click', () => {
            body.classList.remove('activeTabCart');
            body.classList.add('activeTabPayment');
        });
    }

    if (cancelBtn) {
        cancelBtn.addEventListener('click', () => {
            body.classList.remove('activeTabPayment');
            body.classList.add('activeTabCart');
        });
    }

    document.addEventListener('click', (event) => {
        let buttonClick = event.target;
        let idProduct = buttonClick.dataset.id;
        let position = cart.findIndex((value) => value.product_id == idProduct);
        let quantity = position < 0 ? 0 : cart[position].quantity;

        if (buttonClick.classList.contains('addCart') || buttonClick.classList.contains('plus')) {
            quantity++;
            setProductInCart(idProduct, quantity, position);
        } else if (buttonClick.classList.contains('minus')) {
            quantity--;
            setProductInCart(idProduct, quantity, position);
        }
    });

    // Initialize the cart from localStorage
    importCartMemory();
    refreshCartHTML();
};

Cart();
export default Cart;
