<?php
    $folderPath = "../images/*";
    $all_raw_images = glob($folderPath);
    foreach($all_raw_images as $ind=>$file){
        if($file and $ind < 5){
            if($ind == 0){
                echo"
                    <button class='carousel_indicator current-indicator'></button>
                ";
            }else{
                echo"
                    <button class='carousel_indicator'></button>
                ";
            }
        }
    }
?>
