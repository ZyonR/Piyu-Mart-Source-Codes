<section class="carousel_container">
        <div class="carousel_track_container">
            <ul class="carousel_track">
                <?php include 'AnimatedScrollImages.php'; ?>
            </ul>
        </div>
        <div class="carousel_nav">
            <?php include 'carousel_indicator_generator.php'; ?>
        </div>
</section>