import Products from "./products15.js"; // Ensure the correct module is imported

let currentPage = 1;
let itemsPerPage;

const calculateItemsPerPage = () => {
    const gallery = document.querySelector('.gallery');
    const galleryWidth = gallery.offsetWidth;

    if (galleryWidth >= 2055) {
        itemsPerPage = 10;
    } else if (galleryWidth >= 1850) {
        itemsPerPage = 9;
    } else if (galleryWidth >= 1645) {
        itemsPerPage = 8;
    } else if (galleryWidth >= 1440) {
        itemsPerPage = 7;
    } else if (galleryWidth >= 1235) {
        itemsPerPage = 6;
    } else if (galleryWidth >= 1030) {
        itemsPerPage = 5;
    } else if (galleryWidth >= 825) {
        itemsPerPage = 4;
    } else if (galleryWidth >= 620) {
        itemsPerPage = 3;
    } else if (galleryWidth >= 415) {
        itemsPerPage = 2;
    } else {
        itemsPerPage = 1 * 3;
    }
    itemsPerPage *= 2;
    updatePaginationButtons();
    initializedGrid();
    
};

const totalPages = () => Math.ceil(Products.length / itemsPerPage);

const initializedGrid = () => {
    const listProduct = document.querySelector('.gallery');
    listProduct.innerHTML = '';

    const start = (currentPage - 1) * itemsPerPage;
    const end = currentPage * itemsPerPage;
    const currentProducts = Products.slice(start, end);

    currentProducts.forEach(product => {
        const newProduct = document.createElement('section');
        newProduct.classList.add('card');

        // Generate star rating based on review value
        const review = product.review;
        const fullStars = Math.floor(review);
        const reconsiderFullStar = (review - Math.floor(review) >= 0.80 && review - Math.floor(review) < 1.00) ? 1 : 0;
        const halfStar = (review - Math.floor(review) >= 0.30 && review - Math.floor(review) < 0.80) ? 1 : 0;
        const emptyStars = 5 - fullStars - (reconsiderFullStar + halfStar);

        let starRating = '';
        for (let i = 0; i < fullStars; i++) {
            starRating += '<li><i class="bx bxs-star"></i></li>';
        }
        if (reconsiderFullStar) {
            starRating += '<li><i class="bx bxs-star"></i></li>';
        } else if (halfStar) {
            starRating += '<li><i class="bx bxs-star-half"></i></li>';
        }
        for (let i = 0; i < emptyStars; i++) {
            starRating += '<li><i class="bx bx-star"></i></li>';
        }

        newProduct.innerHTML =
            `
                <a href="../product/product.php">
                    <img src="${product.image}">
                    <h3> ${product.name} </h3>
                    <h6>₱ ${product.price} </h6>
                    <p> ${product.description} </p>
                    <section class="product-card-like-and-share">
                        <span><i class='bx bxs-like' ></i> ${product.likes}</span>
                        <span><i class='bx bxs-share-alt' ></i> ${product.shares}</span>
                    </section>
                    <ul>${starRating}</ul>
                </a>
                <button class="addCart" data-id = "${product.id}">Add to Cart</button>
            `;
        listProduct.appendChild(newProduct);
    });

    updatePaginationButtons();
};

const updatePaginationButtons = () => {
    const paginations = document.querySelectorAll('.pagination');
    const total = totalPages();

    paginations.forEach(pagination => {
        pagination.innerHTML = '';

        const createPageButton = (label, page, className) => {
            const btn = document.createElement('a');
            btn.href = "#";
            btn.innerHTML = label;
            btn.className = className;
            btn.addEventListener("click", function(event) {
                event.preventDefault();
                currentPage = page;
                initializedGrid();
            });
            return btn;
        };

        if (total <= 5) {
            for (let i = 1; i <= total; i++) {
                const page = createPageButton(i, i, i === currentPage ? 'active' : '');
                pagination.appendChild(page);
            }
        } else {
            // const first = createPageButton("<i class='bx bx-chevrons-left'></i>", 1, currentPage === 1 ? 'disabled' : '');
            // const prev = createPageButton("<i class='bx bx-chevron-left'></i>", currentPage - 1, currentPage === 1 ? 'disabled' : '');
            // pagination.appendChild(first);
            // pagination.appendChild(prev);

            if (currentPage <= 2) {
                for (let i = 1; i <= 3; i++) {
                    const page = createPageButton(i, i, i === currentPage ? 'active' : '');
                    pagination.appendChild(page);
                }
                const dots = document.createElement('a');
                dots.innerHTML = "<i class='bx bx-dots-horizontal-rounded'></i>";
                dots.className = 'dots';
                pagination.appendChild(dots);
                const lastPage = createPageButton(total, total, '');
                pagination.appendChild(lastPage);
            } else if (currentPage >= total - 1) {
                const firstPage = createPageButton(1, 1, '');
                pagination.appendChild(firstPage);
                const dots = document.createElement('a');
                dots.innerHTML = "<i class='bx bx-dots-horizontal-rounded'></i>";
                dots.className = 'dots';
                pagination.appendChild(dots);
                for (let i = total - 2; i <= total; i++) {
                    const page = createPageButton(i, i, i === currentPage ? 'active' : '');
                    pagination.appendChild(page);
                }
            } else {
                const firstPage = createPageButton(1, 1, '');
                pagination.appendChild(firstPage);
                const dotsBefore = document.createElement('a');
                dotsBefore.innerHTML = "<i class='bx bx-dots-horizontal-rounded'></i>";
                dotsBefore.className = 'dots';
                pagination.appendChild(dotsBefore);
                for (let i = currentPage - 1; i <= currentPage + 1; i++) {
                    const page = createPageButton(i, i, i === currentPage ? 'active' : '');
                    pagination.appendChild(page);
                }
                const dotsAfter = document.createElement('a');
                dotsAfter.innerHTML = "<i class='bx bx-dots-horizontal-rounded'></i>";
                dotsAfter.className = 'dots';
                pagination.appendChild(dotsAfter);
                const lastPage = createPageButton(total, total, '');
                pagination.appendChild(lastPage);
            }

            // const next = createPageButton("<i class='bx bx-chevron-right'></i>", currentPage + 1, currentPage === total ? 'disabled' : '');
            // const last = createPageButton("<i class='bx bx-chevrons-right'></i>", total, currentPage === total ? 'disabled' : '');
            // pagination.appendChild(next);
            // pagination.appendChild(last);
        }
    });
};


window.addEventListener('resize', calculateItemsPerPage);

document.addEventListener("DOMContentLoaded", function() {
    calculateItemsPerPage();
});
