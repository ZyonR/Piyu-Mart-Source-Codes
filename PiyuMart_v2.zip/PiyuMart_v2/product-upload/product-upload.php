<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title></title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../product-upload/product-upload.css">
    <link rel="stylesheet" href="../base.css">
    <link rel="stylesheet" href="../base2.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>

<body>
    <?php include '../header.php' ?>
    <?php include "../product-upload/upload-status.php" ?>
    <div class="product-upload-container">
        <div class="seller-product-form-container">
            <form action=" <?php $_SERVER['PHP_SELF'] ?> " method="post">
                <h3> Add a new product here </h3>
                <section class="input-feild">
                    <label for="productName">Name of the Product</label>
                    <input type="text" placeholder="Enter product Name" name="productName" class="input-box">
                </section>
                <section class="input-feild">
                    <label for="productPrice">Price of the Product</label>
                    <input type="number" placeholder="Enter product Price" name="productPrice" class="input-box">
                </section>
                <section class="input-feild">
                    <label for="productMainPicture">Main Product Picture Overview</label>
                    <input type="file" placeholder="Import one main and primary product image" accept="image/png, image/jpeg, image/jpg" name="productMainPicture" class="input-box">
                </section>
                <section class="input-feild">
                    <label for="productOtherPictures">Secondary Product Pictures</label>
                    <input type="file" placeholder="Import some secondary product images" accept="image/png, image/jpeg, image/jpg" multiple name="productOtherPictures" class="input-box">
                </section>
                <label for="productTags" class="tag-title">Customize the Product Tags</label>
                <section class="tag-feild">
                    <select class="product-tags" name="productTags">
                        <option value="Art">Art</option>
                        <option value="Travel">Travel</option>
                        <option value="Lifestyle">Lifestyle</option>
                        <option value="Feminine">Feminine</option>
                        <option value="Electronics">Electronics</option>
                        <option value="Toys">Toys</option>
                        <option value="Clothing">Clothing</option>
                        <option value="Others">Others</option>
                    </select>
                    <div class="product-add-remove-tags">
                        <button class="product-add-tag"><i class='bx bxs-tag-alt bx-flashing'></i>Add</button>
                        <button class="product-remove-tag"><i class='bx bxs-tag-x bx-flashing'></i>Remove</button>
                    </div>
                </section>
                <section class="product-tags-output">
                    <div class="product-tags">
                        <label for="productTag" class="tag-title">Tags</label>
                        <div class="category-tags">
                            <?php
                            $tags = array("Art", "Travel", "Lifestyle", "Good", "Bad", "Medium", "Feminine");
                            foreach ($tags as $tag) {
                                echo "<button name='productTag' class='product-tag-btn'><a class='product-tag-a' href='#'>$tag</a></button>";
                            }
                            ?>
                        </div>
                    </div>
                </section>
                <input type="submit" class="btn" name="productAdd" value="Add Product">
            </form>
        </div>

        <div class="product-display">
            <table class="product-display-table">
                <thead>
                    <td>Primary Image</td>
                    <td>Product Name</td>
                    <td>Product Price</td>
                    <td colspan="2">Other Actions</td>
                </thead>

                <?php
                // while ($row = mysqli_fetch_assoc()) {
                ?>
                <!-- <tr>
                    <td><img src="uploaded_img/<?php //echo $row['image']; 
                                                ?>" height=100></td>
                    <td><?php //echo $row['name']; 
                        ?></td>
                    <td><?php //echo $row['price']; 
                        ?></td>
                    <td>Other Actions</td>
                </tr> -->
                <?php
                // } 
                ?>
                <tr>
                    <td><img src="../images/1.png" height="100"></td>
                    <td>Dummy Title</td>
                    <td>Dummy Price</td>
                    <td>
                        <a href="../preview-publish/product-prev.php" class="btn">Preview</a>
                        <a href="#" class="btn">Delete</a>
                    </td>
                </tr>
                <tr>
                    <td><img src="../images/2.png" height="100"></td>
                    <td>Dummy Title</td>
                    <td>Dummy Price</td>
                    <td>
                        <a href="../preview-publish/product-prev.php" class="btn">Preview</a>
                        <a href="#" class="btn">Delete</a>
                    </td>
                </tr>
                <tr>
                    <td><img src="../images/3.png" height="100"></td>
                    <td>Dummy Title</td>
                    <td>Dummy Price</td>
                    <td>
                        <a href="../preview-publish/product-prev.php" class="btn">Preview</a>
                        <a href="#" class="btn">Delete</a>
                    </td>
                </tr>
            </table>
        </div>
    </div>
    <script src="" async defer></script>
</body>

</html>