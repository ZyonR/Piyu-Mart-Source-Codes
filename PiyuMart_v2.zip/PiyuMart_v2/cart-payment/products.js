const products = [
    {
        "id": 1,
        "name": "Bottomless Shirt",
        "price": 200,
        "description": "May your serviced be found better.",
        "image": "../images/1.png"
    },
    {
        "id": 2,
        "name": "Mystic T-Shirt",
        "price": 150,
        "description": "Unlock the mysteries of comfort and style.",
        "image": "../images/2.png"
    },
    {
        "id": 3,
        "name": "Cosmic Tee",
        "price": 180,
        "description": "Travel the universe in ultimate comfort.",
        "image": "../images/3.png"
    },
    {
        "id": 4,
        "name": "Vortex V-Neck",
        "price": 220,
        "description": "Swirl into fashion with the Vortex V-Neck.",
        "image": "../images/4.png"
    },
    {
        "id": 5,
        "name": "Galaxy Garb",
        "price": 170,
        "description": "Wear the galaxy on your sleeve.",
        "image": "../images/5.png"
    },
    {
        "id": 6,
        "name": "Stellar Shirt",
        "price": 190,
        "description": "Shine bright with the Stellar Shirt.",
        "image": "../images/6.png"
    },
    {
        "id": 7,
        "name": "Nebula Top",
        "price": 210,
        "description": "Embrace the nebula of comfort and style.",
        "image": "../images/7.png"
    },
    {
        "id": 8,
        "name": "Galactic Hoodie",
        "price": 240,
        "description": "Wrap yourself in the cosmic embrace of this luxurious hoodie.",
        "image": "../images/8.png"
    },
    {
        "id": 9,
        "name": "Infinity Scarf",
        "price": 130,
        "description": "Endless comfort and style await with this versatile accessory.",
        "image": "../images/9.png"
    },
    {
        "id": 10,
        "name": "Celestial Leggings",
        "price": 180,
        "description": "Adorn your legs with the beauty of the cosmos in these comfortable leggings.",
        "image": "../images/10.png"
    },
    {
        "id": 11,
        "name": "Aurora Dress",
        "price": 280,
        "description": "Dance under the aurora borealis in this stunning dress.",
        "image": "../images/11.png"
    },
    {
        "id": 12,
        "name": "Supernova Jacket",
        "price": 320,
        "description": "Stay warm and stylish with this explosively fashionable jacket.",
        "image": "../images/12.png"
    },
    {
        "id": 13,
        "name": "Lunar Boots",
        "price": 210,
        "description": "Step softly across the moon's surface in these comfortable lunar boots.",
        "image": "../images/13.png"
    },
    {
        "id": 14,
        "name": "Interstellar Jeans",
        "price": 200,
        "description": "Travel through the stars in style with these durable interstellar jeans.",
        "image": "../images/14.png"
    },
    {
        "id": 15,
        "name": "Orbiting Earrings",
        "price": 90,
        "description": "Accessorize your look with these elegant earrings that orbit with grace.",
        "image": "../images/15.png"
    }
];

export default products;