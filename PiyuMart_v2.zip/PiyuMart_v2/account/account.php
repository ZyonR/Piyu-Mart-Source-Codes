<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../base.css">
    <link rel="stylesheet" href="acc-styles22.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="../base2.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <title>Document</title>
</head>

<body>
    <?php include "../header.php" ?>
    <br>
    <section class="container">
        <section class="content">
            <div class="account-overview">
                <div class="profile-edit-img-sign-out-container">
                    <div class="profile-img"></div>
                    <div class="edit-sign-out-container">
                        <button class="edit-btn">Edit Profile</button>
                        <button class="sign-out-btn">Sign Out</button>
                    </div>
                </div>
                <div class="basic-information-container">
                    <?php
                    $information_degree = "base";
                    include "guild-informat.php" ?>
                </div>
            </div>
            <div class="account-shop">
                <div class="section-title-button-container">
                    <h2 class="section-title">Your Shop</h2>
                    <div class="shop-btns-a">
                        <a href='../individual-shop/indiv-shop.php'><button class="go-to-shop-btn">Go to Shop</button></a>
                        <button class="del-shop-btn">Delete Shop</button>
                    </div>
                </div>
                <div class="shop-information-container">
                    <?php
                    $information_degree = "shop";
                    include "guild-informat.php" ?>
                </div>
                <p class="dont-have-shop-yet-p">Don't have a shop yet? <a class="register-here-a" href="../register/register.php">Register Here.</a></p>
                <p class="dont-have-shop-yet-p">Want to advertise a product or your shop? <a class="register-here-a" href="../appeal-ads/ads-apppeal.php">Apply Here.</a></p>
            </div>
            <div class="account-privacy">
                <h2 class="section-title">Privacy</h2>
                <div class="privacy-information-container">
                    <?php
                    $information_degree = "privacy";
                    include "guild-informat.php" ?>
                </div>
            </div>
            <div class="account-socials">
                <h2 class="section-title">Socials</h2>
                <div class="socials-tab-information-container">
                    <div class="tab-information-container">
                        <button class="tab-btns" onclick="reviews()">Reviews</button>
                        <button class="tab-btns" onclick="generator_accounts()">Following</button>
                        <button class="tab-btns" onclick="generator_accounts()">Followers</button>
                    </div>
                    <div class="socials-information-container" id="socials-information-container">
                    </div>
                </div>
            </div>
            <div class="account-stats">
                <h2 class="section-title">Statistics</h2>
                <div class="stats-tab-container">
                    <div class="tab-container">
                        <form class="filter-form-statistics">
                            <select>
                                <option value='overall'>Overall Reviews</option>
                                <option value='product quality'>Product Quality</option>
                                <option value='costumer service'>Costumer Service</option>
                                <option value='packaging'>Packaging</option>
                                <option value='price'>Price</option>
                            </select>
                            <fieldset class="radio-btns-filter-stats">
                                <fieldset>
                                    <input type="radio" name='partition'>
                                    <label>Daily</label>
                                </fieldset>
                                <fieldset>
                                    <input type="radio" name='partition'>
                                    <label>Weekly</label>
                                </fieldset>
                                <fieldset>
                                    <input type="radio" name='partition'>
                                    <label>Monthly</label>
                                </fieldset>
                            </fieldset>
                            <input class="apply-filter-stats-btn" type="submit" value="Apply">
                        </form>
                    </div>
                    <div class="stats-information-container" id="stats-information-container">
                    </div>
                </div>
            </div>
            <div class="account-history-orders">
                <div class="section-title-button-container">
                    <h2 class="section-title">Order History</h2>
                    <button class="clear-history-btn">Clear History</button>
                </div>
                <form class="filter-form-statistics">
                    <label class="sort-title">Sort by</label>
                    <select>
                        <option value='date'>Date</option>
                        <option value='overall'>Overall Reviews</option>
                        <option value='product quality'>Product Quality</option>
                        <option value='costumer service'>Costumer Service</option>
                        <option value='packaging'>Packaging</option>
                        <option value='price'>Price</option>
                    </select>
                    <fieldset class="radio-btns-filter-stats">
                        <fieldset>
                            <input type="radio" name='order'>
                            <label>Ascending</label>
                        </fieldset>
                        <fieldset>
                            <input type="radio" name='order'>
                            <label>Descending</label>
                        </fieldset>
                    </fieldset>
                    <input class="apply-filter-stats-btn" type="submit" value="Apply">
                </form>
                <div class="history-orders-container">
                    <?php include "order-history.php" ?>
                </div>
            </div>
            <div class="account-saved-products">
                <div class="section-title-button-container">
                    <h2 class="section-title">Saved Products</h2>
                    <button class="clear-history-btn">Clear All</button>
                </div>
                <form class="filter-form-statistics">
                    <label class="sort-title">Sort by</label>
                    <select>
                        <option value='date'>Date</option>
                        <option value='overall'>Overall Reviews</option>
                        <option value='product quality'>Product Quality</option>
                        <option value='costumer service'>Costumer Service</option>
                        <option value='packaging'>Packaging</option>
                        <option value='price'>Price</option>
                    </select>
                    <fieldset class="radio-btns-filter-stats">
                        <fieldset>
                            <input type="radio" name='order'>
                            <label>Ascending</label>
                        </fieldset>
                        <fieldset>
                            <input type="radio" name='order'>
                            <label>Descending</label>
                        </fieldset>
                    </fieldset>
                    <input class="apply-filter-stats-btn" type="submit" value="Apply">
                </form>
                <div class="saved-products-container">
                    <?php include "saved-products.php" ?>
                </div>
            </div>
            <div class="account-refund-and-return">
                <h2 class="section-title">Refund and Return</h2>
                <form class="refund-return-ticket">
                    <fieldset>
                        <label class="label-inputs">Product ID</label>
                        <input class="input-information-refund-return" type="text">
                    </fieldset>
                    <fieldset>
                        <label class="label-inputs">Transaction ID</label>
                        <input class="input-information-refund-return" type="text">
                    </fieldset>
                    <fieldset>
                        <label class="label-inputs">Store ID</label>
                        <input class="input-information-refund-return" type="text">
                    </fieldset>
                    <fieldset>
                        <label class="label-inputs">Product Recieved</label>
                        <input class="input-information-refund-return choose-file-image" type="file">
                    </fieldset>
                    <textarea></textarea>
                    <input class="submit-btn" type="submit" value="Submit">
                </form>
            </div>
        </section>
    </section>
    <br><br><br>
    <?php include "../footer.php" ?>
    <script src="generators.js"></script>
</body>

</html>