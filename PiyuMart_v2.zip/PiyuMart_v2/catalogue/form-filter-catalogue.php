<?php
    function printLayerOneCheckbox($arr){
        echo "<fieldset class='base-filters'>";
        foreach($arr as $filter){
            echo "  <fieldset>
                        <input type='checkbox' name=".implode("-",explode(" ",strtolower($filter)))." value=".implode("-",explode(" ",strtolower($filter))).">
                        <label>$filter</label>
                    </fieldset>";
        }
        echo "</fieldset>";
    }
    function printCategories(){
        $categoriesAvailable = array("Skin-care","Cosmetics","Designs","Art","Uniforms","Clothes");
        echo "<fieldset class='category-container'>";
        echo "<label class='title-filter'>Categories</label>";
        echo "  <select class='select-category select-style' name='category'>";
        foreach($categoriesAvailable as $category){
            echo " <option value=".$category.">$category</option>";
        }
        echo "</select></fieldset>";
    }
    function printRatings(){
        $categoriesRatings = array("⭐⭐⭐⭐⭐","⭐⭐⭐⭐ &  Up","⭐⭐⭐ &  Up","⭐⭐ &  Up","⭐ &  Up");
        echo "<fieldset  class='rating-container'>";
        echo "<label class='title-filter'>Ratings</label>";
        echo "  <select class='select-style'>";
        foreach($categoriesRatings as $ratings){
            echo "<option value=".$ratings.">$ratings</option>";
        }
        echo "</select></fieldset>";
    }   
    function printPricing(){
        echo "<fieldset class='price-range-container'>";
        echo "<label class='title-filter'>Price Range</label>";
        echo "  <fieldset class='min-to-max-container'>
                    <input class='min' type='number' name='minimum' placeholder='₱ MIN'>
                    <label class='min-to-max'>-</label>
                    <input class='max' type='number' name='maximum' placeholder='₱ MAX'>
                </fieldset> </fieldset>";
            
    }
    $checkboxFirstLayer = array("Recent","Most Reviewed","Top Product Quality","Top Costumer Service");
    echo "  <form  class='filters-form-container'>
            <label class='title-filter'>Filters</label>
            <fieldset class='filters-form'>";
    echo printLayerOneCheckbox($checkboxFirstLayer);
    echo "  <fieldset class='filters-form advanced-filters'>";
    echo printCategories();
    echo printRatings();
    echo printPricing();
    echo    "<input class='submit-btn' type='submit' value='Apply Filter'>
    </fieldset>
            </fieldset>
            </form>";
?>                   