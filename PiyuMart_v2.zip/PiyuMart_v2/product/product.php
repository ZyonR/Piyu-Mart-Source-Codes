<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../base.css">
    <link rel="stylesheet" href="../base2.css">
    <link rel="stylesheet" href="product-style22.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <title>Document</title>
</head>

<body>
    <?php include "../header.php" ?>
    <section class="container">
        <div class="ads-space"></div>
        <br>
        <section class="content">
            <section class="content-child">
                <div class="product-images-with-reviews-and-recommendations">
                    <div class="all-images-container">
                        <div class="hero-product-image-container">
                            <div class="product-base-info">
                                <h1 class="product-name">WOHOO Candy Streaks</h1>
                                <p class="product-price">Php 59.99</p>
                                <p class="product-rating">4.5 Stars</p>
                            </div>
                        </div>
                        <div class="sidekick-product-image-container">
                            <?php
                            for ($i = 0; $i < 3; $i++) {
                                echo "<div class='sidekick-product-image'></div>";
                            }
                            ?>
                        </div>
                    </div>
                    <div class="product-basic-information-2">
                        <div class="shop-information">
                            <div class="store-img"></div>
                            <p class="store-name">WOHOO</p>
                        </div>
                        <div class="product-description-container">
                            <p class="product-description-title">Description</p>
                            <p class="product-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                        </div>
                        <div class="product-buy-n-cart">
                            <div class="product-quantity-container">
                                <p class="product-quantity">Quantity</p>
                                <div class="product-input-quantity-container">
                                    <button class="product-quantity-decrease">-</button>
                                    <input class="product-quantity-input" type="number" />
                                    <button class="product-quantity-increase">+</button>
                                </div>
                            </div>
                            <div class="product-mini-info-container">
                                <p class="product-n-stocks">200+ Available Stocks</p>
                                <p class="product-n-sold">100+ Sold</p>
                            </div>
                            <div class="product-types">
                                <p class="types-title">Product Types</p>
                                <div class="category-types">
                                    <?php

                                    $types = array("4x4", "5x5", "6x6");
                                    foreach ($types as $type) {
                                        echo "<button class='product-types-btn'>$type</button>";
                                    }
                                    ?>
                                </div>
                            </div>
                            <div class="product-buy-now-and-add-to-cart-container">
                                <button class="product-buy-now">Buy Now</button>
                                <button class="product-add-to-cart">Add to Cart</button>
                                <div class="product-share-like-container">
                                    <button class="product-share">Share</button>
                                    <button class="product-like">Like</button>
                                </div>
                            </div>
                        </div>
                        <div class="product-tags">
                            <p class="tag-title">Tags</p>
                            <div class="category-tags">
                                <?php

                                $tags = array("Art", "Travel", "Lifestyle", "Good", "Bad", "Medium", "Feminine");
                                foreach ($tags as $tag) {
                                    echo "<button class='product-tag-btn'><a class='product-tag-a' href='#'>$tag</a></button>";
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                    <div class="reviews-container">
                        <div class="header-container">
                            <h2 class="reviews-title">Reviews</h2>
                            <button class="product-review">Make a Review</button>
                        </div>

                        <div class="reviews-main-container">
                            <?php include "../product/review-new.html" ?>
                            <?php include "review-generator.php" ?>
                        </div>
                    </div>
                    <div class="reco-products-container">
                        <h2 class="reco-products-title">Similar Items</h2>
                        <div class="reco-products-main-container">
                            <?php include "../productGrid/productGrid.html" ?>
                        </div>
                    </div>
                </div>
                <div class="product-basic-information">
                    <div class="shop-information">
                        <div class="store-img"></div>
                        <p class="store-name">WOHOO</p>
                    </div>
                    <div class="product-description-container">
                        <p class="product-description-title">Description</p>
                        <p class="product-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                    </div>
                    <div class="product-buy-n-cart">
                        <div class="product-quantity-container">
                            <p class="product-quantity">Quantity</p>
                            <div class="product-input-quantity-container">
                                <button class="product-quantity-decrease">-</button>
                                <input class="product-quantity-input" type="number" />
                                <button class="product-quantity-increase">+</button>
                            </div>
                        </div>
                        <div class="product-mini-info-container">
                            <p class="product-n-stocks">200+ Available Stocks</p>
                            <p class="product-n-sold">100+ Sold</p>
                        </div>
                        <div class="product-types">
                            <p class="types-title">Product Types</p>
                            <div class="category-types">
                                <?php

                                $types = array("4x4", "5x5", "6x6");
                                foreach ($types as $type) {
                                    echo "<button class='product-types-btn'>$type</button>";
                                }
                                ?>
                            </div>
                        </div>
                        <div class="product-buy-now-and-add-to-cart-container">
                            <button class="product-buy-now">Buy Now</button>
                            <button class="product-add-to-cart">Add to Cart</button>
                            <div class="product-share-like-container">
                                <button class="product-share">Share</button>
                                <button class="product-like">Like</button>
                            </div>
                        </div>
                    </div>
                    <div class="product-tags">
                        <p class="tag-title">Tags</p>
                        <div class="category-tags">
                            <?php

                            $tags = array("Art", "Travel", "Lifestyle", "Good", "Bad", "Medium", "Feminine");
                            foreach ($tags as $tag) {
                                echo "<button class='product-tag-btn'><a class='product-tag-a' href='#'>$tag</a></button>";
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </section>
        </section>
        <br>
        <div class="ads-space"></div>
    </section>
    <br>
    <br>
    <?php include "../footer.php" ?>
</body>

</html>