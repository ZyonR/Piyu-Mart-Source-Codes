const products = [
    {
        "id": 1,
        "name": "Bottomless Shirt",
        "price": 200,
        "description": "May your serviced be found better.",
        "image": "../images/1.png",
        "review": 0.15,
        "likes": 1710,
        "shares": 178
    },
    {
        "id": 2,
        "name": "Mystic T-Shirt",
        "price": 150,
        "description": "Unlock the mysteries of comfort and style.",
        "image": "../images/2.png",
        "review": 0.84,
        "likes": 1732,
        "shares": 306
    },
    {
        "id": 3,
        "name": "Cosmic Tee",
        "price": 180,
        "description": "Travel the universe in ultimate comfort.",
        "image": "../images/3.png",
        "review": 1.1,
        "likes": 3346,
        "shares": 347
    },
    {
        "id": 4,
        "name": "Vortex V-Neck",
        "price": 220,
        "description": "Swirl into fashion with the Vortex V-Neck.",
        "image": "../images/4.png",
        "review": 2.77,
        "likes": 3347,
        "shares": 718
    },
    {
        "id": 5,
        "name": "Galaxy Garb",
        "price": 170,
        "description": "Wear the galaxy on your sleeve.",
        "image": "../images/5.png",
        "review": 0.27,
        "likes": 2264,
        "shares": 639
    },
    {
        "id": 6,
        "name": "Stellar Shirt",
        "price": 190,
        "description": "Shine bright with the Stellar Shirt.",
        "image": "../images/6.png",
        "review": 4.39,
        "likes": 3654,
        "shares": 150
    },
    {
        "id": 7,
        "name": "Nebula Top",
        "price": 210,
        "description": "Embrace the nebula of comfort and style.",
        "image": "../images/7.png",
        "review": 4.05,
        "likes": 3407,
        "shares": 191
    },
    {
        "id": 8,
        "name": "Galactic Hoodie",
        "price": 240,
        "description": "Wrap yourself in the cosmic embrace of this luxurious hoodie.",
        "image": "../images/8.png",
        "review": 0.7,
        "likes": 4434,
        "shares": 120
    },
    {
        "id": 9,
        "name": "Infinity Scarf",
        "price": 130,
        "description": "Endless comfort and style await with this versatile accessory.",
        "image": "../images/9.png",
        "review": 1.28,
        "likes": 860,
        "shares": 22
    },
    {
        "id": 10,
        "name": "Celestial Leggings",
        "price": 180,
        "description": "Adorn your legs with the beauty of the cosmos in these comfortable leggings.",
        "image": "../images/10.png",
        "review": 3.35,
        "likes": 4311,
        "shares": 868
    },
    {
        "id": 11,
        "name": "Aurora Dress",
        "price": 280,
        "description": "Dance under the aurora borealis in this stunning dress.",
        "image": "../images/11.png",
        "review": 4.09,
        "likes": 3889,
        "shares": 680
    },
    {
        "id": 12,
        "name": "Supernova Jacket",
        "price": 320,
        "description": "Stay warm and stylish with this explosively fashionable jacket.",
        "image": "../images/12.png",
        "review": 3.22,
        "likes": 1228,
        "shares": 236
    },
    {
        "id": 13,
        "name": "Lunar Boots",
        "price": 210,
        "description": "Step softly across the moon's surface in these comfortable lunar boots.",
        "image": "../images/13.png",
        "review": 4.72,
        "likes": 4104,
        "shares": 853
    },
    {
        "id": 14,
        "name": "Interstellar Jeans",
        "price": 200,
        "description": "Travel through the stars in style with these durable interstellar jeans.",
        "image": "../images/14.png",
        "review": 3.89,
        "likes": 4197,
        "shares": 893
    },
    {
        "id": 15,
        "name": "Orbiting Earrings",
        "price": 90,
        "description": "Accessorize your look with these elegant earrings that orbit with grace.",
        "image": "../images/15.png",
        "review": 0.59,
        "likes": 2291,
        "shares": 255
    },
    {
        "id": 16,
        "name": "Burger Alter",
        "price": 200,
        "description": "This is a randomly generated product description.",
        "image": "../images/81.jpg",
        "review": 0.81,
        "likes": 2972,
        "shares": 790
    },
    {
        "id": 17,
        "name": "Neverending Slices",
        "price": 194,
        "description": "This is a randomly generated product description.",
        "image": "../images/82.jpg",
        "review": 4.15,
        "likes": 3697,
        "shares": 785
    },
    {
        "id": 18,
        "name": "Geometric Cheese",
        "price": 372,
        "description": "This is a randomly generated product description.",
        "image": "../images/83.jpg",
        "review": 4.88,
        "likes": 4165,
        "shares": 176
    },
    {
        "id": 19,
        "name": "Random Product 19",
        "price": 110,
        "description": "This is a randomly generated product description.",
        "image": "../images/84.jpg",
        "review": 1.02,
        "likes": 2993,
        "shares": 657
    },
    {
        "id": 20,
        "name": "Random Product 20",
        "price": 257,
        "description": "This is a randomly generated product description.",
        "image": "../images/85.jpg",
        "review": 1.28,
        "likes": 2478,
        "shares": 964
    },
    {
        "id": 21,
        "name": "Random Product 21",
        "price": 259,
        "description": "This is a randomly generated product description.",
        "image": "../images/82.jpg",
        "review": 1.81,
        "likes": 1416,
        "shares": 706
    },
    {
        "id": 22,
        "name": "Random Product 22",
        "price": 302,
        "description": "This is a randomly generated product description.",
        "image": "../images/84.jpg",
        "review": 1.24,
        "likes": 4389,
        "shares": 655
    },
    {
        "id": 23,
        "name": "Random Product 23",
        "price": 220,
        "description": "This is a randomly generated product description.",
        "image": "../images/85.jpg",
        "review": 0.81,
        "likes": 4544,
        "shares": 950
    },
    {
        "id": 24,
        "name": "Random Product 24",
        "price": 147,
        "description": "This is a randomly generated product description.",
        "image": "../images/84.jpg",
        "review": 5.0,
        "likes": 2685,
        "shares": 848
    },
    {
        "id": 25,
        "name": "Random Product 25",
        "price": 266,
        "description": "This is a randomly generated product description.",
        "image": "../images/81.jpg",
        "review": 4.16,
        "likes": 3953,
        "shares": 612
    },
    {
        "id": 26,
        "name": "Random Product 26",
        "price": 476,
        "description": "This is a randomly generated product description.",
        "image": "../images/85.jpg",
        "review": 4.23,
        "likes": 2892,
        "shares": 794
    },
    {
        "id": 27,
        "name": "Random Product 27",
        "price": 106,
        "description": "This is a randomly generated product description.",
        "image": "../images/85.jpg",
        "review": 2.53,
        "likes": 2976,
        "shares": 124
    },
    {
        "id": 28,
        "name": "Random Product 28",
        "price": 309,
        "description": "This is a randomly generated product description.",
        "image": "../images/85.jpg",
        "review": 3.17,
        "likes": 3811,
        "shares": 714
    },
    {
        "id": 29,
        "name": "Random Product 29",
        "price": 197,
        "description": "This is a randomly generated product description.",
        "image": "../images/83.jpg",
        "review": 0.06,
        "likes": 1705,
        "shares": 690
    },
    {
        "id": 30,
        "name": "Random Product 30",
        "price": 276,
        "description": "This is a randomly generated product description.",
        "image": "../images/84.jpg",
        "review": 4.09,
        "likes": 1018,
        "shares": 386
    }
];

export default products;
