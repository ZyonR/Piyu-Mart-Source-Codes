import Products from "./products15.js"; // Ensure the correct module is imported

let currentPage = 1;
let itemsPerPage;

const calculateItemsPerPage = () => {
    const gallery = document.querySelector('.gallery');
    const galleryWidth = gallery.offsetWidth;

    if (galleryWidth >= 2055) {
        itemsPerPage = 10;
    } else if (galleryWidth >= 1850) {
        itemsPerPage = 9;
    } else if (galleryWidth >= 1645) {
        itemsPerPage = 8;
    } else if (galleryWidth >= 1440) {
        itemsPerPage = 7;
    } else if (galleryWidth >= 1235) {
        itemsPerPage = 6;
    } else if (galleryWidth >= 1030) {
        itemsPerPage = 5;
    } else if (galleryWidth >= 825) {
        itemsPerPage = 4;
    } else if (galleryWidth >= 425) {
        itemsPerPage = 3;
    } else if (galleryWidth >= 375) {
        itemsPerPage = 2;
    } else {
        itemsPerPage = 1 * 3;
    }
    itemsPerPage *= 2;
    updatePaginationButtons();
    initializedGrid();
};

const totalPages = () => Math.ceil(Products.length / itemsPerPage);

const initializedGrid = () => {
    const listProduct = document.querySelector('.gallery');
    listProduct.innerHTML = '';

    const start = (currentPage - 1) * itemsPerPage;
    const end = currentPage * itemsPerPage;
    const currentProducts = Products.slice(start, end);

    currentProducts.forEach(product => {
        const newProduct = document.createElement('section');
        newProduct.classList.add('card');

        // Generate star rating based on review value
        const review = product.review;
        const fullStars = Math.floor(review);
        const reconsiderFullStar = (review - Math.floor(review) >= 0.80 && review - Math.floor(review) < 1.00) ? 1 : 0;
        const halfStar = (review - Math.floor(review) >= 0.30 && review - Math.floor(review) < 0.80) ? 1 : 0;
        const emptyStars = 5 - fullStars - (reconsiderFullStar + halfStar);

        let starRating = '';
        for (let i = 0; i < fullStars; i++) {
            starRating += '<li><i class="bx bxs-star"></i></li>';
        }
        if (reconsiderFullStar) {
            starRating += '<li><i class="bx bxs-star"></i></li>';
        } else if (halfStar) {
            starRating += '<li><i class="bx bxs-star-half"></i></li>';
        }
        for (let i = 0; i < emptyStars; i++) {
            starRating += '<li><i class="bx bx-star"></i></li>';
        }

        newProduct.innerHTML =
            `
                <a href="../product/product.php">
                    <img src="${product.image}">
                    <h3> ${product.name} </h3>
                    <h6>₱ ${product.price} </h6>
                    <p> ${product.description} </p>
                    <section class="product-card-like-and-share">
                        <span><i class='bx bxs-like' ></i> ${product.likes}</span>
                        <span><i class='bx bxs-share-alt' ></i> ${product.shares}</span>
                    </section>
                    <ul>${starRating}</ul>
                </a>
                <button class="addCart" data-id = "${product.id}">Add to Cart</button>
            `;
        listProduct.appendChild(newProduct);
    });

    updatePaginationButtons();
};

const updatePaginationButtons = () => {
    const pagination = document.querySelector('.pagination');
    pagination.innerHTML = '';

    const first = document.createElement('a');
    first.href = "#";
    first.id = "first";
    first.innerHTML = "<i class='bx bx-chevrons-left'></i>";
    first.style.display = currentPage === 1 ? "none" : "inline-block";
    pagination.appendChild(first);

    const prev = document.createElement('a');
    prev.href = "#";
    prev.id = "prev";
    prev.innerHTML = "<i class='bx bx-chevron-left'></i>";
    prev.style.display = currentPage === 1 ? "none" : "inline-block";
    pagination.appendChild(prev);

    for (let i = 1; i <= totalPages(); i++) {
        const page = document.createElement('a');
        page.href = "#";
        page.id = `page${i}`;
        page.textContent = i;
        if (i === currentPage) {
            page.classList.add('active');
        }
        pagination.appendChild(page);

        page.addEventListener("click", function(event) {
            event.preventDefault();
            currentPage = i;
            initializedGrid();
        });
    }

    const next = document.createElement('a');
    next.href = "#";
    next.id = "next";
    next.innerHTML = "<i class='bx bx-chevron-right'></i>";
    next.style.display = currentPage === totalPages() ? "none" : "inline-block";
    pagination.appendChild(next);

    const last = document.createElement('a');
    last.href = "#";
    last.id = "last";
    last.innerHTML = "<i class='bx bx-chevrons-right'></i>";
    last.style.display = currentPage === totalPages() ? "none" : "inline-block";
    pagination.appendChild(last);

    first.addEventListener("click", function(event) {
        event.preventDefault();
        currentPage = 1;
        initializedGrid();
    });

    prev.addEventListener("click", function(event) {
        event.preventDefault();
        if (currentPage > 1) {
            currentPage--;
            initializedGrid();
        }
    });

    next.addEventListener("click", function(event) {
        event.preventDefault();
        if (currentPage < totalPages()) {
            currentPage++;
            initializedGrid();
        }
    });

    last.addEventListener("click", function(event) {
        event.preventDefault();
        currentPage = totalPages();
        initializedGrid();
    });
};

window.addEventListener('resize', calculateItemsPerPage);

document.addEventListener("DOMContentLoaded", function() {
    calculateItemsPerPage();
});
