<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="../base.css">
    <link rel="stylesheet" href="sign-in-up.css">
    <title>Piyumart</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="">
</head>

<body>
    <?php include '../header.php' ?>
    <div class="background">

    </div>
    <div class="container">
        <div class="content">
            <h2 class="piyumart-logo">
                <i class='bx bxs-basket'></i> Piyu<span>MART</span>
            </h2>
            <div class="text-sci">
                <h2>Welcome<br><span>P U Marts!</span></h2>
                <p> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s. </p>
                <div class="social-icons">
                    <a href="#"><i class='bx bxl-facebook'></i></a>
                    <a href="#"><i class='bx bxl-twitter'></i></a>
                    <a href="#"><i class='bx bxl-discord'></i></a>
                    <a href="#"><i class='bx bxl-linkedin-square'></i></a>
                    <a href="#"><i class='bx bxl-instagram'></i></a>
                </div>
            </div>
        </div>
        <div class="login-register-box"> <!-- with JS variable 1st: COMPOSED OF TWO PARENT DIVS: FOR LOGIN AND REGISTER -->
            <div class="form-box login">
                <form action="#">
                    <h2>Sign In</h2>
                    <div class="input-box">
                        <span class="icon"><i class='bx bx-envelope bx-tada'></i></span>
                        <input type="email" placeholder="" require>
                        <label>Email</label>
                    </div>
                    <div class="input-box">
                        <span class="icon"><i class='bx bx-lock-alt bx-tada'></i></span>
                        <input type="password" placeholder="" require>
                        <label>Password</label>
                    </div>
                    <div class="remember-forgot">
                        <label>
                            <input type="checkbox"> Remember me
                        </label>
                        <a href="#">Forgot Password? </a>
                    </div>
                    <button type="submit" class="btn">Sign In</button>
                    <div class="login-register">
                        <p>Do not have an account? <a href="#" class="register-link">Sign Up!</a></p><!-- with JS variable 2nd: LOGIN PARENT DIV -->
                    </div>
                </form>
            </div>

            <div class="form-box register">
                <form action="#">
                    <h2>Sign Up</h2>
                    <div class="input-box">
                        <span class="icon"><i class='bx bx-user bx-tada'></i></span>
                        <input type="text" placeholder="" require>
                        <label>Name</label>
                    </div>
                    <div class="input-box">
                        <span class="icon"><i class='bx bx-envelope bx-tada'></i></span>
                        <input type="email" placeholder="" require>
                        <label>Email</label>
                    </div>
                    <div class="input-box">
                        <span class="icon"><i class='bx bxs-phone bx-tada'></i></span>
                        <input type="text" placeholder="" require>
                        <label>Number</label>
                    </div>
                    <div class="input-box">
                        <span class="icon"><i class='bx bx-lock-alt bx-tada'></i></span>
                        <input type="password" placeholder="" require>
                        <label>Password</label>
                    </div>
                    <div class="remember-forgot">
                        <label>
                            <input type="checkbox"> I agree to the <a href="#">terms and conditions</a>
                        </label>
                    </div>
                    <button type="submit" class="btn">Sign Up</button>
                    <div class="login-register">
                        <p>Already have an account? <a href="#" class="login-link">Sign In!</a></p><!-- with JS variable 3rd: REGISTER PARENT DIV -->
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script src="sign-in-up.js" async defer></script>
</body>

</html>