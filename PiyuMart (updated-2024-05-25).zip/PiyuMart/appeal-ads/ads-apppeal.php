<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../base.css">
    <link rel="stylesheet" href="ads-styles.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <title>Document</title>
</head>
<body>
    <?php include "../header.php" ?>
    <br>
    <section class="container">
        <div class="mechanics-container">
            <h1 class="title-paragraph">Mechanics</h1>
            <p class="mechanics-paragraph">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Eget nullam non nisi est. Nibh mauris cursus mattis molestie a iaculis. Urna et pharetra pharetra massa massa ultricies. Fermentum posuere urna nec tincidunt. Tempor orci eu lobortis elementum nibh tellus. Sed enim ut sem viverra aliquet eget sit amet. Nunc consequat interdum varius sit amet mattis vulputate. At ultrices mi tempus imperdiet nulla malesuada pellentesque elit. Eleifend donec pretium vulputate sapien nec sagittis aliquam malesuada bibendum.</p>
        </div>
        <form class="ads-space-tx" action="../ads-preview/ads-prev.php">
            <label class="add-space-title">Advertisment Space Ticket</label>
            <fieldset>
                <fieldset class="mobile-info-enter">
                    <label>Product Name</label>
                    <input class="style-input" type="text"/>
                </fieldset>
                <fieldset class="mobile-info-enter">
                    <label>Product Price</label>
                    <input class="style-input" type="number"/>
                </fieldset>
                <fieldset class="mobile-info-enter">
                    <label id="upload-ad-img" for="advertisment-img">Upload Image</label>
                    <input type="file" class="advertisment-img" id="advertisment-img" name="advertisment-img">
                    <div class="show-file-name-here-cymon"><p># File Name</p></div>
                </fieldset>
                <fieldset class="mobile-info-enter">
                    <label>Length of Advertisment</label>
                    <select class="style-input">
                        <option value="">1 month</option>
                        <option value="">1 Week</option>
                        <option value="">1 day</option>
                    </select>
                </fieldset>
                <fieldset class="prev-cancel-btns-container">
                    <input type="submit" value="Preview" />
                    <!-- reset data from form -->
                    <input type="button" value="Cancel" />
                </fieldset>
            </fieldset>
        </form>
    </section>
    <br><br><br>
    <?php include "../footer.php" ?>
</body>
</html>
