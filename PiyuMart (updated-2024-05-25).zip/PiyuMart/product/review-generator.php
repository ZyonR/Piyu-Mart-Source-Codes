<?php
    function map_reviews($arr){
        foreach($arr as $value){
            echo"
            <a href='../review/review.php'>
                <div class='review'>
                    <div class='review-top-section'>
                        <div class='review-account-img'>".$value['img']."</div>
                        <div class='review-account-info'>
                            <p class='review-account-info-name'>".$value['name']."</p>
                            <p class='review-account-info-date'>".$value['review-posted']."</p>
                        </div>
                    </div>
                    <div class='review-parameters-and-paragraph'>
                        <div class='review-parameters'>";
                            array_map(function($k, $val) {
                                echo "<p class='review-parameters-text'>$k: $val</p>";
                            }, array_keys($value['parameters']), $value['parameters']);
                        echo "</div>
                        <p class='review-paragraph'>".$value['review']."</p>
                    </div>
                </div>
            </a>
            ";
        }
    }
    $arr = array([
            "name"=> "Regis Luctano",
            "img"=>"",
            "review-posted"=>"2024-01-01",
            "review"=>"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
            "parameters" => ["Product Quality"=>4.5,"Price"=>5,"Customer Service"=>4.7,"Packaging"=>3.5]
        ],
        [
            "name"=> "Regis Luctano",
            "img"=>"",
            "review-posted"=>"2024-01-01",
            "review"=>"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
            "parameters" => ["Product Quality"=>4.5,"Price"=>5,"Customer Service"=>4.7,"Packaging"=>3.5]
        ],
        [
            "name"=> "Regis Luctano",
            "img"=>"",
            "review-posted"=>"2024-01-01",
            "review"=>"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
            "parameters" => ["Product Quality"=>4.5,"Price"=>5,"Customer Service"=>4.7,"Packaging"=>3.5]
        ],
        [
            "name"=> "Regis Luctano",
            "img"=>"",
            "review-posted"=>"2024-01-01",
            "review"=>"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
            "parameters" => ["Product Quality"=>4.5,"Price"=>5,"Customer Service"=>4.7,"Packaging"=>3.5]
        ]
    );
    map_reviews($arr);
?>