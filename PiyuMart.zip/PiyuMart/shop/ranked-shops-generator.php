<?php 
    function shops_mapping($array){
        return(
            "<div class='shop-container'>
                <div class='shop-img'>".$array['shop-img']."</div>
                <div class='shop-base-info'>
                    <h2 class='shop-name'>".$array['shop-name']."</h2>
                    <p class='shop-n-followers'>".$array['shop-n-followers']." followers</p>
                    <button class='shop-follow-btn'>Follow</button>
                </div>
            </div>"
        );
    }
    $tags = array("Fashion", "Lifestyle", "Art", "Academics", "All Shops");
    $shop_information = array(
        [
            "shop-name"=>"Dippy Dy Co. number 1 giddy",
            "shop-n-followers"=>12,
            "shop-img"=>""
        ],
        [
            "shop-name"=>"Dippy Dy Co.",
            "shop-n-followers"=>12,
            "shop-img"=>""
        ],
        [
            "shop-name"=>"Dippy Dy Co.",
            "shop-n-followers"=>12,
            "shop-img"=>""
        ],
    );
    $shop_information = array_map('shops_mapping',$shop_information);
    foreach ($tags as $tag) {
        echo "
            <div class='tag-shops-container'>
                <h2 class='top-shops-tag-title'>$tag</h2>
                <div class='shops'>".implode("",$shop_information)."</div>  
            </div>
        ";
    }
?>
